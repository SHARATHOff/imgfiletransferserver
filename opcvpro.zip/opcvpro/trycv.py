import cv2

img = cv2.VideoCapture('wp.jpg')

convert1 = cv2.cvtColor(img,cv2.COLOR_BAYER_BG2GRAY)
cv2.imshow('coverted ',convert1)
cv2.waitKey(0)