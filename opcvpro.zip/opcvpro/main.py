import cv2
traninedfacemodel = cv2.CascadeClassifier(r"C:\Users\SHARATH BALAN\Documents\Programming\opcvpro\haarcascade_frontalface_default.xml")
webcam = cv2.VideoCapture(1)
while True:
    work,video = webcam.read()
    blackwhite= cv2.cvtColor(video,cv2.COLOR_BGR2GRAY)
    face = traninedfacemodel.detectMultiScale(blackwhite)
    for (x,y,w,h) in face:
        cv2.rectangle(video,(x,y),(x+w,y+h),(0,0,200),3)
    cv2.imshow("hai",video)
    key = cv2.waitKey(1)
    if key==27:
        break